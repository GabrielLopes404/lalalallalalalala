# Fluxo de Autenticação - Sistema LUCREI

## Visão Geral

O sistema LUCREI utiliza autenticação baseada em sessão com Passport.js e PostgreSQL como store persistente. Este documento detalha todos os fluxos de autenticação implementados.

---

## Fluxo de Registro

### 1. Criação de Conta

**Endpoint:** `POST /api/register`

**Payload:**
```json
{
  "email": "usuario@exemplo.com",
  "password": "SenhaForte123!",
  "name": "Nome do Usuário"
}
```

**Processo:**
1. Sistema valida formato do email
2. Verifica se email já existe no banco
3. Valida força da senha (mínimo 8 caracteres, maiúscula, minúscula, número)
4. Gera hash da senha com bcrypt (12 rounds)
5. Cria registro de usuário com `emailVerified: false`
6. Gera `verificationToken` único (UUID)
7. Envia email de verificação via Resend
8. Retorna `201 Created` com dados do usuário (sem senha)

**Resposta de Sucesso:**
```json
{
  "user": {
    "id": "uuid-xxx",
    "email": "usuario@exemplo.com",
    "name": "Nome do Usuário",
    "emailVerified": false
  }
}
```

**Erros Possíveis:**
- `400 Bad Request`: Email já cadastrado
- `400 Bad Request`: Senha fraca
- `500 Internal Server Error`: Falha ao enviar email

---

### 2. Verificação de Email

**Endpoint:** `GET /verify-email?token=xxx`

**Processo:**
1. Sistema busca usuário pelo `verificationToken`
2. Valida que token não expirou (24h)
3. Atualiza `emailVerified: true`
4. Invalida token (remove do banco)
5. Redireciona para `/login` com mensagem de sucesso

**Fluxo Alternativo - Reenvio de Email:**

**Endpoint:** `POST /api/auth/resend-verification`

```json
{
  "email": "usuario@exemplo.com"
}
```

1. Valida que usuário existe
2. Verifica que email ainda não foi verificado
3. Gera novo token
4. Envia novo email
5. Retorna `200 OK`

---

## Fluxo de Login

### 1. Autenticação

**Endpoint:** `POST /api/login`

**Payload:**
```json
{
  "email": "usuario@exemplo.com",
  "password": "SenhaForte123!"
}
```

**Processo:**
1. Sistema busca usuário por email
2. Valida se usuário existe
3. **Verifica se `emailVerified: true`**
   - ❌ Se false: Retorna `403 Forbidden` com opção de reenvio
4. Compara senha com hash usando bcrypt
5. Cria sessão no PostgreSQL
6. Define cookie de sessão (httpOnly, secure em prod)
7. Retorna dados do usuário

**Resposta de Sucesso:**
```json
{
  "user": {
    "id": "uuid-xxx",
    "email": "usuario@exemplo.com",
    "name": "Nome do Usuário",
    "role": "OWNER",
    "organizationId": "org-uuid"
  }
}
```

**Erros Possíveis:**
- `401 Unauthorized`: Credenciais inválidas
- `403 Forbidden`: Email não verificado
- `429 Too Many Requests`: Rate limit (5 tentativas em 15 minutos)

---

### 2. Verificação de Sessão

**Endpoint:** `GET /api/user`

**Processo:**
1. Middleware verifica cookie de sessão
2. Busca sessão no PostgreSQL
3. Carrega dados do usuário
4. Retorna usuário autenticado ou `401`

**Resposta:**
```json
{
  "user": {
    "id": "uuid-xxx",
    "email": "usuario@exemplo.com",
    "name": "Nome do Usuário",
    "role": "OWNER"
  }
}
```

---

### 3. Logout

**Endpoint:** `POST /api/logout`

**Processo:**
1. Destrói sessão no PostgreSQL
2. Remove cookie de sessão
3. Retorna `200 OK`

---

## Fluxo de Recuperação de Senha

### 1. Solicitação de Reset

**Endpoint:** `POST /api/auth/forgot-password`

**Payload:**
```json
{
  "email": "usuario@exemplo.com"
}
```

**Processo:**
1. Busca usuário por email
2. Gera `resetToken` único (UUID)
3. Define `resetTokenExpiry` (1 hora a partir de agora)
4. Envia email com link de reset
5. **Sempre retorna `200 OK`** (evita enumeration attack)

**Email enviado:**
```
Assunto: Redefinir sua senha - Lucrei

Olá,

Recebemos uma solicitação para redefinir sua senha.

Clique no link abaixo para criar uma nova senha:
https://lucrei.app/reset-password?token=abc123

Este link expira em 1 hora.

Se você não solicitou isso, ignore este email.
```

---

### 2. Validação de Token

**Endpoint:** `GET /api/auth/validate-reset-token?token=xxx`

**Processo:**
1. Busca token no banco
2. Verifica se não expirou
3. Retorna `200 OK` ou `400 Bad Request`

---

### 3. Reset de Senha

**Endpoint:** `POST /api/auth/reset-password`

**Payload:**
```json
{
  "token": "reset-token-uuid",
  "newPassword": "NovaSenhaForte123!"
}
```

**Processo:**
1. Valida token existe e não expirou
2. Valida força da nova senha
3. Gera hash da nova senha (bcrypt, 12 rounds)
4. Atualiza senha do usuário
5. Invalida `resetToken` (remove do banco)
6. **Destrói todas as sessões ativas do usuário** (força re-login)
7. Envia email de confirmação
8. Retorna `200 OK`

**Email de confirmação:**
```
Assunto: Senha alterada com sucesso - Lucrei

Sua senha foi alterada com sucesso.

Se você não fez esta alteração, entre em contato conosco imediatamente.
```

---

## Segurança

### Rate Limiting

Todos os endpoints de autenticação têm rate limiting:

| Endpoint | Limite |
|----------|--------|
| `/api/login` | 5 tentativas por IP em 15 minutos |
| `/api/register` | 3 registros por IP em 1 hora |
| `/api/auth/forgot-password` | 3 solicitações por email em 1 hora |
| `/api/auth/reset-password` | 5 tentativas por token |

### Proteções Implementadas

1. **Passwords:**
   - Bcrypt com 12 rounds
   - Validação de força obrigatória
   - Nunca retornados em responses

2. **Sessions:**
   - Armazenadas em PostgreSQL (persistentes)
   - Cookies httpOnly e secure (em produção)
   - Expiração configurável (default: 7 dias)

3. **Tokens:**
   - UUIDs aleatórios (não sequenciais)
   - Expiração curta (1h para reset, 24h para verificação)
   - One-time use (invalidados após uso)

4. **CSRF Protection:**
   - Token CSRF em todos os forms
   - Validação obrigatória em POST/PUT/DELETE

5. **Enumeration Prevention:**
   - `/forgot-password` sempre retorna 200 OK
   - Mensagens de erro genéricas ("Credenciais inválidas")

---

## Fluxo de Organização Multi-Tenant

### Estrutura

```
User (1) ──belongs to──> Organization (1)
User has role: OWNER | ADMIN | CUSTOMER
```

### Roles e Permissões

| Ação | OWNER | ADMIN | CUSTOMER |
|------|-------|-------|----------|
| Criar organização | ✅ | ❌ | ❌ |
| Convidar usuários | ✅ | ✅ | ❌ |
| Gerenciar plano/pagamento | ✅ | ❌ | ❌ |
| Ver todas transações | ✅ | ✅ | ❌ |
| Ver próprias transações | ✅ | ✅ | ✅ |
| Gerar relatórios | ✅ | ✅ | ❌ |
| Editar configurações | ✅ | ✅ | ❌ |

### Isolamento de Dados

Todas as queries incluem filtro automático por `organizationId`:

```sql
SELECT * FROM transactions 
WHERE organization_id = $1 
AND user_id = $2; -- Se CUSTOMER
```

---

## Diagramas de Sequência

### Fluxo Completo de Registro

```
User          →  Frontend  →  Backend  →  Database  →  Resend
   |              |            |            |            |
   |-- Preenche --|            |            |            |
   |    formulário|            |            |            |
   |              |            |            |            |
   |              |-- POST /api/register -->|            |
   |              |            |            |            |
   |              |            |-- INSERT ->|            |
   |              |            |<-- user id-|            |
   |              |            |            |            |
   |              |            |-- Send email ---------->|
   |              |            |<-- 200 OK -------------|
   |              |            |            |            |
   |              |<-- 201 Created ---------|            |
   |              |            |            |            |
   |<-- Mensagem: |            |            |            |
   | "Verifique   |            |            |            |
   |  seu email"  |            |            |            |
```

### Fluxo de Login

```
User       →  Frontend  →  Backend  →  Database
   |           |            |            |
   |-- Enter --|            |            |
   | email/pwd |            |            |
   |           |            |            |
   |           |-- POST /api/login ----->|
   |           |            |            |
   |           |            |-- Query -->|
   |           |            |<-- user ---|
   |           |            |            |
   |           |            |-- bcrypt   |
   |           |            |  compare   |
   |           |            |            |
   |           |            |-- Create ->|
   |           |            |   session  |
   |           |            |            |
   |           |<-- Set-Cookie: sid -----|
   |<-- Redirect to /dashboard ---------|
```

---

## Testes

### Casos de Teste Críticos

1. **Registro:**
   - ✅ Email único
   - ✅ Senha forte validada
   - ✅ Email de verificação enviado
   - ❌ Não permite login sem verificação

2. **Login:**
   - ✅ Credenciais corretas
   - ❌ Email não verificado bloqueia
   - ❌ Senha incorreta retorna 401
   - ✅ Sessão criada corretamente

3. **Password Reset:**
   - ✅ Token expira em 1h
   - ✅ Token é one-time use
   - ✅ Todas sessões invalidadas
   - ❌ Token inválido retorna 400

---

## Troubleshooting

### Usuário não recebe email de verificação

1. Verificar `RESEND_API_KEY` está configurada
2. Verificar domínio verificado no Resend
3. Checar logs: `docker logs lucrei-web | grep -i resend`
4. Testar manualmente: `curl -X POST /api/auth/resend-verification`

### Sessão expirou muito rápido

1. Verificar `maxAge` no session config (padrão: 7 dias)
2. Verificar cookie não está sendo bloqueado
3. Verificar PostgreSQL session store está funcionando

### Login não funciona após password reset

1. Verificar hash da senha foi atualizado
2. Verificar sessões antigas foram destruídas
3. Verificar `bcrypt.compare()` está funcionando

---

**Última Atualização:** 04 de Novembro de 2025  
**Mantido por:** Equipe de Engenharia  
**Próxima Revisão:** Mensal
