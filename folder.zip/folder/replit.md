# LUCREI - Sistema de Gestão Financeira SaaS

## Overview
LUCREI is a comprehensive SaaS financial management system for small and medium-sized businesses. It offers robust management of organizations, clients, invoices, financial transactions, categories, cost centers, documents, tags, OFX imports, exports, and detailed reports. The project aims to provide a modern, responsive, and fully functional platform that centralizes financial operations and enhances business efficiency with a standardized, intuitive user experience.

## User Preferences
- I prefer simple language and clear explanations.
- I want iterative development with frequent updates and feedback loops.
- Ask before making major changes to the core architecture or existing functionalities.
- Ensure all new features align with the established design system and visual patterns.
- Prioritize security and data integrity in all implementations.
- Do not make changes to the file `design_guidelines.md`.

## System Architecture
LUCREI is built with a client-server architecture using **React 18** (Vite) for the frontend and **Express.js** (Node.js 20) for the backend. **TypeScript** is used across the entire stack for type safety.

### UI/UX Decisions
The system follows a modern, standardized design with a focus on responsiveness and user-friendliness.
- **Consistent Design System:** All pages adhere to a modern visual standard using `shadcn/ui` components.
- **Theming:** Supports dark/light themes with `next-themes`.
- **Animations:** Smooth transitions and micro-interactions are implemented using `Framer Motion`.
- **Visuals:** Features gradients in titles, colored cards with shadows, gradient-backed Lucide React icons, and colored badges for status indicators.
- **Data Visualization:** Interactive charts and graphs are powered by `Recharts`.
- **Mobile Responsiveness:** Enhanced with fluid typography, touch-optimized hover effects, horizontal scroll for tables, and responsive image handling.

### Technical Implementations
- **Backend:**
    - **Database:** PostgreSQL with `Drizzle ORM` for schema management and data access. Session storage uses PostgreSQL via `connect-pg-simple`.
    - **API:** Full RESTful API supporting CRUD operations for all entities (Organizations, Users, Customers, Invoices, Transactions, Categories, Cost Centers, Tags, Documents, Bank Accounts, Reconciliations, User Preferences, Subscriptions). Includes dedicated endpoints for metrics, activity logs, financial reports (DRE, Cash Flow, Statement), and data exports.
    - **Authentication:** Session-based authentication using `Passport.js` and `express-session` with PostgreSQL store, password hashing via `bcryptjs` (12 rounds). Includes password reset and email verification flows. Session regeneration implemented on login/register to prevent session fixation attacks.
    - **Authorization:** Role-based access control (OWNER, ADMIN, CUSTOMER) and organization-level data isolation.
    - **Validation:** Server-side data validation using `Zod` schemas.
    - **Security:** `Helmet` for HTTP headers, CORS configured for production, `express-rate-limit` for rate limiting, CSRF protection globally applied, mandatory `SESSION_SECRET`.
    - **Exports:** XLSX and CSV generation using `xlsx` and `json2csv` libraries.
    - **CSV Import:** Complete CSV parsing, validation, and bulk transaction creation with preview and error handling.
    - **File Uploads:** Multer with MIME validation, size limits, and secure storage in uploads/ directory.
    - **Bank Account Management:** Automatic balance recalculation on transaction create/update/delete operations.
    - **Monitoring & Logging:** Sentry for error tracking, Winston for structured logging with file rotation.
    - **Email Service:** Resend integration with HTML templates for notifications (invoices, payments, reports).
    - **OFX Parser:** Financial file parsing and matching.
    - **PDF Export:** DRE, Cash Flow, Statement, and Invoice generation with PDFKit.
    - **Caching:** Memoization with TTL.
- **Frontend:**
    - **State Management & Data Fetching:** `TanStack Query (React Query)` handles data fetching, caching, and synchronization.
    - **Routing:** Light-weight client-side routing with `Wouter`.
    - **Form Management:** `React Hook Form` integrated with `Zod` for client-side validation.
    - **Error Handling:** Root and route-level error boundaries.
    - **Loading States:** Spinners, skeletons, and progress indicators.
    - **Accessibility:** Radix UI components ensure accessibility.
    - **Code Splitting:** Lazy loading setup.

### Feature Specifications
- **Core Modules:** Management for Customers, Invoices, Transactions, Categories, Cost Centers, Tags, Documents, Bank Accounts, Reconciliations, User Preferences, and Subscriptions.
- **Dashboard:** Centralized view with key metrics, interactive charts, recent activities, and invoice statistics.
- **Financial Transactions:** Complete transaction management with support for income/expense categorization, bank account linking, cost center allocation, tags, and document attachments.
- **Reporting:** Real-time financial reports (DRE, Cash Flow, Statement).
- **Data Operations:** Excel, CSV, and JSON exports; OFX reconciliation.
- **Settings:** User profile, preferences (theme, language, notifications), and organization management.

### System Design Choices
- **Modularity:** Project structure separates client, server, and shared code.
- **Scalability:** Designed with considerations for future scalability.
- **Observability:** Focus on logging and monitoring in production environments with Sentry and Winston.
- **Deployment:** Configured for automated deployment with autoscale capabilities.

## Recent Changes (November 2025)
- **Security Enhancements:**
  - Implemented session regeneration on login/register to prevent session fixation attacks
  - Increased bcrypt rounds from 10 to 12 for stronger password hashing
  - CSRF protection verified and working globally for all POST/PUT/DELETE endpoints
  - CORS properly configured with ALLOWED_ORIGINS for production environment
- **Bank Account Features:**
  - Implemented automatic balance recalculation on all transaction operations
  - currentBalance now updates automatically when transactions are created, updated, or deleted
  - Handles bank account changes on transaction updates correctly
- **CSV Import System:**
  - Full CSV parsing and validation with detailed error reporting
  - Bulk transaction creation from CSV files (up to 1000 transactions per import)
  - Template download endpoint for standardized CSV format
  - Preview functionality before committing transactions
- **PDF Generation:**
  - Statement PDF export endpoint implemented (/api/reports/statement/pdf)
  - Supports all existing reports: DRE, Cash Flow, Statement, and Invoices
- **File Management:**
  - Secure file upload system with Multer
  - Document storage in uploads/ directory with proper authentication
  - Download and preview endpoints for uploaded documents
- **Notifications System:**
  - Complete in-app notifications table and API
  - Support for different notification types: invoice_due, payment_received, low_balance, subscription_expiring, system
  - Mark as read/unread functionality
  - Bulk mark all as read
  - User-specific and organization-level notifications
- **Recurring Transactions:**
  - Full recurring transactions management system
  - Support for daily, weekly, monthly, yearly frequencies
  - Active/inactive status control
  - Start/end date configuration
  - Complete CRUD API for recurring transaction management
  - Automated cron job that runs daily at midnight to generate transactions from active recurring configurations
- **Invoice Email System:**
  - Professional HTML email templates for invoices
  - Send invoice by email endpoint (/api/invoices/:id/send-email)
  - Automatic email generation with invoice details, customer info, and organization branding
  - Integration with Resend API (falls back to console logging in development)
- **CSV Import System - COMPLETE:**
  - Frontend: Full CSV import dialog with file upload, preview table (first 10 rows), validation error display
  - Backend: Robust CSV parsing with validation and error handling
  - Preview before import showing total rows and column headers
  - Real-time validation with detailed error messages
  - Support for description, amount, type, date, category columns
- **Notifications In-App System - COMPLETE:**
  - Bell icon in header with unread count badge (red badge showing number of unread)
  - Dropdown panel showing last 5 notifications
  - Mark individual notification as read (click to mark)
  - Mark all notifications as read button
  - Real-time polling every 30 seconds
  - Visual distinction for unread notifications (blue background)
  - Support for notification types: invoice_due, payment_received, low_balance, subscription_expiring, system
- **Deployment:**
  - Configured autoscale deployment with proper build and run scripts
  - Production-ready with environment variable support
- **Dashboard:**
  - Fixed hardcoded username 'Gabriel' to display dynamic user name from req.user.name

## External Dependencies
- **Stripe:** For payment processing and subscription management.
- **Resend:** Email service for notifications and transactional emails.
- **PostgreSQL:** Primary database, utilized with `@neondatabase/serverless`.
- **connect-pg-simple:** PostgreSQL session store for `express-session`.
- **Passport.js:** Authentication middleware.
- **bcryptjs:** Password hashing library (12 rounds).
- **Zod:** Schema declaration and validation library.
- **xlsx:** Excel file generation.
- **json2csv:** CSV file generation and parsing.
- **csv-parse:** CSV parsing for imports.
- **PDFKit:** PDF generation for reports and invoices.
- **Multer:** File upload handling.
- **Recharts:** Charting library.
- **Lucide React:** Icon library.
- **Framer Motion:** Animation library.
- **TanStack Query (React Query):** Data fetching and caching library.
- **shadcn/ui:** UI component library.
- **Tailwind CSS:** Utility-first CSS framework.
- **Vite:** Frontend build tool.
- **Sentry:** Error tracking and performance monitoring.
- **Winston:** Structured logging.