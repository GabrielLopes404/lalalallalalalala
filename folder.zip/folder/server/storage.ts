import { eq, and, desc, sql, gte, lte, asc, count } from "drizzle-orm";
import { db } from "./db";
import { PaginatedResponse } from "./pagination";
import {
  type User,
  type InsertUser,
  type Organization,
  type InsertOrganization,
  type Customer,
  type InsertCustomer,
  type Invoice,
  type InsertInvoice,
  type Subscription,
  type InsertSubscription,
  type Activity,
  type InsertActivity,
  type Category,
  type InsertCategory,
  type BankAccount,
  type InsertBankAccount,
  type CostCenter,
  type InsertCostCenter,
  type Tag,
  type InsertTag,
  type Transaction,
  type InsertTransaction,
  type Document,
  type InsertDocument,
  type Reconciliation,
  type InsertReconciliation,
  type UserPreferences,
  type InsertUserPreferences,
  type ApiKey,
  type InsertApiKey,
  type Notification,
  type InsertNotification,
  type RecurringTransaction,
  type InsertRecurringTransaction,
  users,
  organizations,
  customers,
  invoices,
  subscriptions,
  activities,
  categories,
  bankAccounts,
  costCenters,
  tags,
  transactions,
  transactionTags,
  documents,
  reconciliations,
  userPreferences,
  apiKeys,
  notifications,
  recurringTransactions,
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;
  getUsersByOrganization(organizationId: string): Promise<User[]>;

  // Organizations
  getOrganization(id: string): Promise<Organization | undefined>;
  createOrganization(org: InsertOrganization): Promise<Organization>;
  updateOrganization(id: string, org: Partial<InsertOrganization>): Promise<Organization | undefined>;
  deleteOrganization(id: string): Promise<boolean>;
  getAllOrganizations(): Promise<Organization[]>;

  // Customers
  getCustomer(id: string): Promise<Customer | undefined>;
  getCustomersByOrganization(organizationId: string): Promise<Customer[]>;
  getCustomersByOrganizationPaginated(organizationId: string, offset: number, limit: number): Promise<{ data: Customer[]; total: number }>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: string, customer: Partial<InsertCustomer>): Promise<Customer | undefined>;
  deleteCustomer(id: string): Promise<boolean>;

  // Invoices
  getInvoice(id: string): Promise<Invoice | undefined>;
  getInvoicesByOrganization(organizationId: string): Promise<Invoice[]>;
  getInvoicesByOrganizationPaginated(organizationId: string, offset: number, limit: number): Promise<{ data: Invoice[]; total: number }>;
  getInvoicesByCustomer(customerId: string): Promise<Invoice[]>;
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  updateInvoice(id: string, invoice: Partial<InsertInvoice>): Promise<Invoice | undefined>;
  deleteInvoice(id: string): Promise<boolean>;
  getInvoiceByNumber(invoiceNumber: string): Promise<Invoice | undefined>;

  // Subscriptions
  getSubscription(id: string): Promise<Subscription | undefined>;
  getSubscriptionByOrganization(organizationId: string): Promise<Subscription | undefined>;
  getSubscriptionByStripeId(stripeSubscriptionId: string): Promise<Subscription | undefined>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  updateSubscription(id: string, subscription: Partial<InsertSubscription>): Promise<Subscription | undefined>;
  deleteSubscription(id: string): Promise<boolean>;

  // Activities
  createActivity(activity: InsertActivity): Promise<Activity>;
  getActivitiesByOrganization(organizationId: string, limit?: number): Promise<Activity[]>;

  // Metrics
  getMetrics(organizationId: string): Promise<{
    totalCustomers: number;
    totalInvoices: number;
    totalRevenue: string;
    paidInvoices: number;
    pendingInvoices: number;
    overdueInvoices: number;
  }>;

  // Monthly Revenue Data
  getMonthlyRevenueData(organizationId: string): Promise<Array<{
    month: string;
    monthIndex: number;
    receita: number;
  }>>;

  // Categories
  getCategory(id: string): Promise<Category | undefined>;
  getCategoriesByOrganization(organizationId: string): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: string, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: string): Promise<boolean>;

  // Bank Accounts
  getBankAccount(id: string): Promise<BankAccount | undefined>;
  getBankAccountsByOrganization(organizationId: string): Promise<BankAccount[]>;
  createBankAccount(account: InsertBankAccount): Promise<BankAccount>;
  updateBankAccount(id: string, account: Partial<InsertBankAccount>): Promise<BankAccount | undefined>;
  deleteBankAccount(id: string): Promise<boolean>;

  // Cost Centers
  getCostCenter(id: string): Promise<CostCenter | undefined>;
  getCostCentersByOrganization(organizationId: string): Promise<CostCenter[]>;
  createCostCenter(center: InsertCostCenter): Promise<CostCenter>;
  updateCostCenter(id: string, center: Partial<InsertCostCenter>): Promise<CostCenter | undefined>;
  deleteCostCenter(id: string): Promise<boolean>;

  // Tags
  getTag(id: string): Promise<Tag | undefined>;
  getTagsByOrganization(organizationId: string): Promise<Tag[]>;
  createTag(tag: InsertTag): Promise<Tag>;
  updateTag(id: string, tag: Partial<InsertTag>): Promise<Tag | undefined>;
  deleteTag(id: string): Promise<boolean>;

  // Transactions
  getTransaction(id: string): Promise<Transaction | undefined>;
  getTransactionsByOrganization(organizationId: string): Promise<Transaction[]>;
  getTransactionsByOrganizationPaginated(organizationId: string, offset: number, limit: number): Promise<{ data: Transaction[]; total: number }>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: string, transaction: Partial<InsertTransaction>): Promise<Transaction | undefined>;
  deleteTransaction(id: string): Promise<boolean>;
  addTagToTransaction(transactionId: string, tagId: string): Promise<void>;
  removeTagFromTransaction(transactionId: string, tagId: string): Promise<void>;
  getTransactionTags(transactionId: string): Promise<Tag[]>;

  // Documents
  getDocument(id: string): Promise<Document | undefined>;
  getDocumentsByOrganization(organizationId: string): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: string, document: Partial<InsertDocument>): Promise<Document | undefined>;
  deleteDocument(id: string): Promise<boolean>;

  // Reconciliations
  getReconciliation(id: string): Promise<Reconciliation | undefined>;
  getReconciliationsByOrganization(organizationId: string): Promise<Reconciliation[]>;
  createReconciliation(reconciliation: InsertReconciliation): Promise<Reconciliation>;
  updateReconciliation(id: string, reconciliation: Partial<InsertReconciliation>): Promise<Reconciliation | undefined>;
  deleteReconciliation(id: string): Promise<boolean>;

  // User Preferences
  getUserPreferences(userId: string): Promise<UserPreferences | undefined>;
  createUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences>;
  updateUserPreferences(userId: string, preferences: Partial<InsertUserPreferences>): Promise<UserPreferences | undefined>;

  // Notifications
  getNotification(id: string): Promise<Notification | undefined>;
  getNotificationsByOrganization(organizationId: string, limit?: number): Promise<Notification[]>;
  getNotificationsByUser(userId: string, limit?: number): Promise<Notification[]>;
  getUnreadNotificationsByUser(userId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: string): Promise<Notification | undefined>;
  markAllNotificationsAsRead(userId: string): Promise<number>;
  deleteNotification(id: string): Promise<boolean>;

  // Recurring Transactions
  getRecurringTransaction(id: string): Promise<RecurringTransaction | undefined>;
  getRecurringTransactionsByOrganization(organizationId: string): Promise<RecurringTransaction[]>;
  getActiveRecurringTransactions(organizationId: string): Promise<RecurringTransaction[]>;
  createRecurringTransaction(transaction: InsertRecurringTransaction): Promise<RecurringTransaction>;
  updateRecurringTransaction(id: string, transaction: Partial<InsertRecurringTransaction>): Promise<RecurringTransaction | undefined>;
  deleteRecurringTransaction(id: string): Promise<boolean>;

  // Reports
  getDREReport(organizationId: string, startDate?: Date, endDate?: Date): Promise<any>;
  getCashFlowReport(organizationId: string, startDate?: Date, endDate?: Date): Promise<any>;
  getStatementReport(organizationId: string, startDate?: Date, endDate?: Date): Promise<any>;
}

export class DbStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined> {
    const result = await db
      .update(users)
      .set({ ...user, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async deleteUser(id: string): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id)).returning();
    return result.length > 0;
  }

  async getUsersByOrganization(organizationId: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.organizationId, organizationId));
  }

  // Organizations
  async getOrganization(id: string): Promise<Organization | undefined> {
    const result = await db.select().from(organizations).where(eq(organizations.id, id)).limit(1);
    return result[0];
  }

  async createOrganization(org: InsertOrganization): Promise<Organization> {
    const result = await db.insert(organizations).values(org).returning();
    return result[0];
  }

  async updateOrganization(id: string, org: Partial<InsertOrganization>): Promise<Organization | undefined> {
    const result = await db
      .update(organizations)
      .set({ ...org, updatedAt: new Date() })
      .where(eq(organizations.id, id))
      .returning();
    return result[0];
  }

  async deleteOrganization(id: string): Promise<boolean> {
    const result = await db.delete(organizations).where(eq(organizations.id, id)).returning();
    return result.length > 0;
  }

  async getAllOrganizations(): Promise<Organization[]> {
    return await db.select().from(organizations).orderBy(desc(organizations.createdAt));
  }

  // Customers
  async getCustomer(id: string): Promise<Customer | undefined> {
    const result = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
    return result[0];
  }

  async getCustomersByOrganization(organizationId: string): Promise<Customer[]> {
    return await db
      .select()
      .from(customers)
      .where(eq(customers.organizationId, organizationId))
      .orderBy(desc(customers.createdAt));
  }

  async getCustomersByOrganizationPaginated(organizationId: string, offset: number, limit: number): Promise<{ data: Customer[]; total: number }> {
    const [data, totalResult] = await Promise.all([
      db
        .select()
        .from(customers)
        .where(eq(customers.organizationId, organizationId))
        .orderBy(desc(customers.createdAt))
        .limit(limit)
        .offset(offset),
      db
        .select({ count: count() })
        .from(customers)
        .where(eq(customers.organizationId, organizationId))
    ]);
    return { data, total: Number(totalResult[0].count) };
  }

  async createCustomer(customer: InsertCustomer): Promise<Customer> {
    const result = await db.insert(customers).values(customer).returning();
    return result[0];
  }

  async updateCustomer(id: string, customer: Partial<InsertCustomer>): Promise<Customer | undefined> {
    const result = await db
      .update(customers)
      .set({ ...customer, updatedAt: new Date() })
      .where(eq(customers.id, id))
      .returning();
    return result[0];
  }

  async deleteCustomer(id: string): Promise<boolean> {
    const result = await db.delete(customers).where(eq(customers.id, id)).returning();
    return result.length > 0;
  }

  // Invoices
  async getInvoice(id: string): Promise<Invoice | undefined> {
    const result = await db.select().from(invoices).where(eq(invoices.id, id)).limit(1);
    return result[0];
  }

  async getInvoicesByOrganization(organizationId: string): Promise<Invoice[]> {
    return await db
      .select()
      .from(invoices)
      .where(eq(invoices.organizationId, organizationId))
      .orderBy(desc(invoices.createdAt));
  }

  async getInvoicesByOrganizationPaginated(organizationId: string, offset: number, limit: number): Promise<{ data: Invoice[]; total: number }> {
    const [data, totalResult] = await Promise.all([
      db
        .select()
        .from(invoices)
        .where(eq(invoices.organizationId, organizationId))
        .orderBy(desc(invoices.createdAt))
        .limit(limit)
        .offset(offset),
      db
        .select({ count: count() })
        .from(invoices)
        .where(eq(invoices.organizationId, organizationId))
    ]);
    return { data, total: Number(totalResult[0].count) };
  }

  async getInvoicesByCustomer(customerId: string): Promise<Invoice[]> {
    return await db
      .select()
      .from(invoices)
      .where(eq(invoices.customerId, customerId))
      .orderBy(desc(invoices.createdAt));
  }

  async createInvoice(invoice: InsertInvoice): Promise<Invoice> {
    const result = await db.insert(invoices).values(invoice).returning();
    return result[0];
  }

  async updateInvoice(id: string, invoice: Partial<InsertInvoice>): Promise<Invoice | undefined> {
    const result = await db
      .update(invoices)
      .set({ ...invoice, updatedAt: new Date() })
      .where(eq(invoices.id, id))
      .returning();
    return result[0];
  }

  async deleteInvoice(id: string): Promise<boolean> {
    const result = await db.delete(invoices).where(eq(invoices.id, id)).returning();
    return result.length > 0;
  }

  async getInvoiceByNumber(invoiceNumber: string): Promise<Invoice | undefined> {
    const result = await db
      .select()
      .from(invoices)
      .where(eq(invoices.invoiceNumber, invoiceNumber))
      .limit(1);
    return result[0];
  }

  // Subscriptions
  async getSubscription(id: string): Promise<Subscription | undefined> {
    const result = await db.select().from(subscriptions).where(eq(subscriptions.id, id)).limit(1);
    return result[0];
  }

  async getSubscriptionByOrganization(organizationId: string): Promise<Subscription | undefined> {
    const result = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.organizationId, organizationId))
      .orderBy(desc(subscriptions.createdAt))
      .limit(1);
    return result[0];
  }

  async getSubscriptionByStripeId(stripeSubscriptionId: string): Promise<Subscription | undefined> {
    const result = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.stripeSubscriptionId, stripeSubscriptionId))
      .limit(1);
    return result[0];
  }

  async createSubscription(subscription: InsertSubscription): Promise<Subscription> {
    const result = await db.insert(subscriptions).values(subscription).returning();
    return result[0];
  }

  async updateSubscription(id: string, subscription: Partial<InsertSubscription>): Promise<Subscription | undefined> {
    const result = await db
      .update(subscriptions)
      .set({ ...subscription, updatedAt: new Date() })
      .where(eq(subscriptions.id, id))
      .returning();
    return result[0];
  }

  async deleteSubscription(id: string): Promise<boolean> {
    const result = await db.delete(subscriptions).where(eq(subscriptions.id, id)).returning();
    return result.length > 0;
  }

  // Activities
  async createActivity(activity: InsertActivity): Promise<Activity> {
    const result = await db.insert(activities).values(activity).returning();
    return result[0];
  }

  async getActivitiesByOrganization(organizationId: string, limit: number = 50): Promise<Activity[]> {
    return await db
      .select()
      .from(activities)
      .where(eq(activities.organizationId, organizationId))
      .orderBy(desc(activities.createdAt))
      .limit(limit);
  }

  // Metrics
  async getMetrics(organizationId: string): Promise<{
    totalCustomers: number;
    totalInvoices: number;
    totalRevenue: string;
    paidInvoices: number;
    pendingInvoices: number;
    overdueInvoices: number;
  }> {
    const [customersCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(customers)
      .where(eq(customers.organizationId, organizationId));

    const [invoicesCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(invoices)
      .where(eq(invoices.organizationId, organizationId));

    const [revenue] = await db
      .select({ total: sql<string>`COALESCE(SUM(${invoices.amount}), 0)` })
      .from(invoices)
      .where(and(eq(invoices.organizationId, organizationId), eq(invoices.status, "paid")));

    const [paid] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(invoices)
      .where(and(eq(invoices.organizationId, organizationId), eq(invoices.status, "paid")));

    const [pending] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(invoices)
      .where(and(eq(invoices.organizationId, organizationId), eq(invoices.status, "pending")));

    const [overdue] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(invoices)
      .where(and(eq(invoices.organizationId, organizationId), eq(invoices.status, "overdue")));

    return {
      totalCustomers: customersCount?.count || 0,
      totalInvoices: invoicesCount?.count || 0,
      totalRevenue: revenue?.total || "0",
      paidInvoices: paid?.count || 0,
      pendingInvoices: pending?.count || 0,
      overdueInvoices: overdue?.count || 0,
    };
  }

  // Monthly Revenue Data
  async getMonthlyRevenueData(organizationId: string): Promise<Array<{
    month: string;
    monthIndex: number;
    receita: number;
  }>> {
    const now = new Date();
    const monthNames = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
    
    // Generate last 6 months
    const last6Months = [];
    for (let i = 5; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      last6Months.push({
        year: date.getFullYear(),
        month: date.getMonth() + 1,
        monthName: monthNames[date.getMonth()],
        monthIndex: date.getMonth()
      });
    }

    // Get actual revenue data
    const revenueData = await db
      .select({
        year: sql<number>`EXTRACT(YEAR FROM ${invoices.issueDate})::int`,
        month: sql<number>`EXTRACT(MONTH FROM ${invoices.issueDate})::int`,
        receita: sql<number>`COALESCE(SUM(CASE WHEN ${invoices.status} = 'paid' THEN ${invoices.amount}::numeric ELSE 0 END), 0)::float`,
      })
      .from(invoices)
      .where(eq(invoices.organizationId, organizationId))
      .groupBy(sql`EXTRACT(YEAR FROM ${invoices.issueDate})`, sql`EXTRACT(MONTH FROM ${invoices.issueDate})`);

    // Map revenue to months, filling gaps with 0
    return last6Months.map(monthInfo => {
      const data = revenueData.find(r => r.year === monthInfo.year && r.month === monthInfo.month);
      return {
        month: monthInfo.monthName,
        monthIndex: monthInfo.monthIndex,
        receita: data?.receita || 0
      };
    });
  }

  // Categories
  async getCategory(id: string): Promise<Category | undefined> {
    const result = await db.select().from(categories).where(eq(categories.id, id)).limit(1);
    return result[0];
  }

  async getCategoriesByOrganization(organizationId: string): Promise<Category[]> {
    return await db
      .select()
      .from(categories)
      .where(eq(categories.organizationId, organizationId))
      .orderBy(asc(categories.name));
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const result = await db.insert(categories).values(category).returning();
    return result[0];
  }

  async updateCategory(id: string, category: Partial<InsertCategory>): Promise<Category | undefined> {
    const result = await db
      .update(categories)
      .set({ ...category, updatedAt: new Date() })
      .where(eq(categories.id, id))
      .returning();
    return result[0];
  }

  async deleteCategory(id: string): Promise<boolean> {
    const result = await db.delete(categories).where(eq(categories.id, id)).returning();
    return result.length > 0;
  }

  // Bank Accounts
  async getBankAccount(id: string): Promise<BankAccount | undefined> {
    const result = await db.select().from(bankAccounts).where(eq(bankAccounts.id, id)).limit(1);
    return result[0];
  }

  async getBankAccountsByOrganization(organizationId: string): Promise<BankAccount[]> {
    return await db
      .select()
      .from(bankAccounts)
      .where(eq(bankAccounts.organizationId, organizationId))
      .orderBy(asc(bankAccounts.name));
  }

  async createBankAccount(account: InsertBankAccount): Promise<BankAccount> {
    const result = await db.insert(bankAccounts).values(account).returning();
    return result[0];
  }

  async updateBankAccount(id: string, account: Partial<InsertBankAccount>): Promise<BankAccount | undefined> {
    const result = await db
      .update(bankAccounts)
      .set({ ...account, updatedAt: new Date() })
      .where(eq(bankAccounts.id, id))
      .returning();
    return result[0];
  }

  async deleteBankAccount(id: string): Promise<boolean> {
    const result = await db.delete(bankAccounts).where(eq(bankAccounts.id, id)).returning();
    return result.length > 0;
  }

  // Cost Centers
  async getCostCenter(id: string): Promise<CostCenter | undefined> {
    const result = await db.select().from(costCenters).where(eq(costCenters.id, id)).limit(1);
    return result[0];
  }

  async getCostCentersByOrganization(organizationId: string): Promise<CostCenter[]> {
    return await db
      .select()
      .from(costCenters)
      .where(eq(costCenters.organizationId, organizationId))
      .orderBy(asc(costCenters.name));
  }

  async createCostCenter(center: InsertCostCenter): Promise<CostCenter> {
    const result = await db.insert(costCenters).values(center).returning();
    return result[0];
  }

  async updateCostCenter(id: string, center: Partial<InsertCostCenter>): Promise<CostCenter | undefined> {
    const result = await db
      .update(costCenters)
      .set({ ...center, updatedAt: new Date() })
      .where(eq(costCenters.id, id))
      .returning();
    return result[0];
  }

  async deleteCostCenter(id: string): Promise<boolean> {
    const result = await db.delete(costCenters).where(eq(costCenters.id, id)).returning();
    return result.length > 0;
  }

  // Tags
  async getTag(id: string): Promise<Tag | undefined> {
    const result = await db.select().from(tags).where(eq(tags.id, id)).limit(1);
    return result[0];
  }

  async getTagsByOrganization(organizationId: string): Promise<Tag[]> {
    return await db
      .select()
      .from(tags)
      .where(eq(tags.organizationId, organizationId))
      .orderBy(asc(tags.name));
  }

  async createTag(tag: InsertTag): Promise<Tag> {
    const result = await db.insert(tags).values(tag).returning();
    return result[0];
  }

  async updateTag(id: string, tag: Partial<InsertTag>): Promise<Tag | undefined> {
    const result = await db
      .update(tags)
      .set({ ...tag, updatedAt: new Date() })
      .where(eq(tags.id, id))
      .returning();
    return result[0];
  }

  async deleteTag(id: string): Promise<boolean> {
    const result = await db.delete(tags).where(eq(tags.id, id)).returning();
    return result.length > 0;
  }

  // Transactions
  async getTransaction(id: string): Promise<Transaction | undefined> {
    const result = await db.select().from(transactions).where(eq(transactions.id, id)).limit(1);
    return result[0];
  }

  async getTransactionsByOrganization(organizationId: string): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.organizationId, organizationId))
      .orderBy(desc(transactions.date));
  }

  async getTransactionsByOrganizationPaginated(organizationId: string, offset: number, limit: number): Promise<{ data: Transaction[]; total: number }> {
    const [data, totalResult] = await Promise.all([
      db
        .select()
        .from(transactions)
        .where(eq(transactions.organizationId, organizationId))
        .orderBy(desc(transactions.date))
        .limit(limit)
        .offset(offset),
      db
        .select({ count: count() })
        .from(transactions)
        .where(eq(transactions.organizationId, organizationId))
    ]);
    return { data, total: Number(totalResult[0].count) };
  }

  private async recalculateBankAccountBalance(bankAccountId: string): Promise<void> {
    // Get the bank account to get initial balance
    const account = await this.getBankAccount(bankAccountId);
    if (!account) return;

    // Calculate sum of all transactions for this account
    const transactionsData = await db
      .select()
      .from(transactions)
      .where(eq(transactions.bankAccountId, bankAccountId));

    let balance = parseFloat(account.initialBalance || '0');
    
    for (const trans of transactionsData) {
      const amount = parseFloat(trans.amount);
      if (trans.type === 'income') {
        balance += amount;
      } else {
        balance -= amount;
      }
    }

    // Update the current balance
    await db
      .update(bankAccounts)
      .set({ currentBalance: balance.toFixed(2), updatedAt: new Date() })
      .where(eq(bankAccounts.id, bankAccountId));
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const result = await db.insert(transactions).values(transaction).returning();
    
    // Update bank account balance if transaction is linked to an account
    if (result[0].bankAccountId) {
      await this.recalculateBankAccountBalance(result[0].bankAccountId);
    }
    
    return result[0];
  }

  async updateTransaction(id: string, transaction: Partial<InsertTransaction>): Promise<Transaction | undefined> {
    // Get old transaction to check if bank account changed
    const oldTransaction = await this.getTransaction(id);
    
    const result = await db
      .update(transactions)
      .set({ ...transaction, updatedAt: new Date() })
      .where(eq(transactions.id, id))
      .returning();
    
    if (result[0]) {
      // Update balance for old bank account if it changed
      if (oldTransaction?.bankAccountId && oldTransaction.bankAccountId !== result[0].bankAccountId) {
        await this.recalculateBankAccountBalance(oldTransaction.bankAccountId);
      }
      
      // Update balance for new/current bank account
      if (result[0].bankAccountId) {
        await this.recalculateBankAccountBalance(result[0].bankAccountId);
      }
    }
    
    return result[0];
  }

  async deleteTransaction(id: string): Promise<boolean> {
    // Get transaction before deleting to update bank account
    const transaction = await this.getTransaction(id);
    
    const result = await db.delete(transactions).where(eq(transactions.id, id)).returning();
    
    // Update bank account balance if transaction was linked to an account
    if (result.length > 0 && transaction?.bankAccountId) {
      await this.recalculateBankAccountBalance(transaction.bankAccountId);
    }
    
    return result.length > 0;
  }

  async addTagToTransaction(transactionId: string, tagId: string): Promise<void> {
    await db.insert(transactionTags).values({ transactionId, tagId });
  }

  async removeTagFromTransaction(transactionId: string, tagId: string): Promise<void> {
    await db
      .delete(transactionTags)
      .where(and(eq(transactionTags.transactionId, transactionId), eq(transactionTags.tagId, tagId)));
  }

  async getTransactionTags(transactionId: string): Promise<Tag[]> {
    const result = await db
      .select({
        id: tags.id,
        organizationId: tags.organizationId,
        name: tags.name,
        color: tags.color,
        createdAt: tags.createdAt,
        updatedAt: tags.updatedAt,
      })
      .from(transactionTags)
      .innerJoin(tags, eq(transactionTags.tagId, tags.id))
      .where(eq(transactionTags.transactionId, transactionId));
    return result;
  }

  // Documents
  async getDocument(id: string): Promise<Document | undefined> {
    const result = await db.select().from(documents).where(eq(documents.id, id)).limit(1);
    return result[0];
  }

  async getDocumentsByOrganization(organizationId: string): Promise<Document[]> {
    return await db
      .select()
      .from(documents)
      .where(eq(documents.organizationId, organizationId))
      .orderBy(desc(documents.createdAt));
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const result = await db.insert(documents).values(document).returning();
    return result[0];
  }

  async updateDocument(id: string, document: Partial<InsertDocument>): Promise<Document | undefined> {
    const result = await db
      .update(documents)
      .set({ ...document, updatedAt: new Date() })
      .where(eq(documents.id, id))
      .returning();
    return result[0];
  }

  async deleteDocument(id: string): Promise<boolean> {
    const result = await db.delete(documents).where(eq(documents.id, id)).returning();
    return result.length > 0;
  }

  // Reconciliations
  async getReconciliation(id: string): Promise<Reconciliation | undefined> {
    const result = await db.select().from(reconciliations).where(eq(reconciliations.id, id)).limit(1);
    return result[0];
  }

  async getReconciliationsByOrganization(organizationId: string): Promise<Reconciliation[]> {
    return await db
      .select()
      .from(reconciliations)
      .where(eq(reconciliations.organizationId, organizationId))
      .orderBy(desc(reconciliations.uploadDate));
  }

  async createReconciliation(reconciliation: InsertReconciliation): Promise<Reconciliation> {
    const result = await db.insert(reconciliations).values(reconciliation).returning();
    return result[0];
  }

  async updateReconciliation(id: string, reconciliation: Partial<InsertReconciliation>): Promise<Reconciliation | undefined> {
    const result = await db
      .update(reconciliations)
      .set({ ...reconciliation, updatedAt: new Date() })
      .where(eq(reconciliations.id, id))
      .returning();
    return result[0];
  }

  async deleteReconciliation(id: string): Promise<boolean> {
    const result = await db.delete(reconciliations).where(eq(reconciliations.id, id)).returning();
    return result.length > 0;
  }

  // User Preferences
  async getUserPreferences(userId: string): Promise<UserPreferences | undefined> {
    const result = await db.select().from(userPreferences).where(eq(userPreferences.userId, userId)).limit(1);
    return result[0];
  }

  async createUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences> {
    const result = await db.insert(userPreferences).values(preferences).returning();
    return result[0];
  }

  async updateUserPreferences(userId: string, preferences: Partial<InsertUserPreferences>): Promise<UserPreferences | undefined> {
    const result = await db
      .update(userPreferences)
      .set({ ...preferences, updatedAt: new Date() })
      .where(eq(userPreferences.userId, userId))
      .returning();
    return result[0];
  }

  // Notifications
  async getNotification(id: string): Promise<Notification | undefined> {
    const result = await db.select().from(notifications).where(eq(notifications.id, id)).limit(1);
    return result[0];
  }

  async getNotificationsByOrganization(organizationId: string, limit = 50): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.organizationId, organizationId))
      .orderBy(desc(notifications.createdAt))
      .limit(limit);
  }

  async getNotificationsByUser(userId: string, limit = 50): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt))
      .limit(limit);
  }

  async getUnreadNotificationsByUser(userId: string): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const result = await db.insert(notifications).values(notification).returning();
    return result[0];
  }

  async markNotificationAsRead(id: string): Promise<Notification | undefined> {
    const result = await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id))
      .returning();
    return result[0];
  }

  async markAllNotificationsAsRead(userId: string): Promise<number> {
    const result = await db
      .update(notifications)
      .set({ isRead: true })
      .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)))
      .returning();
    return result.length;
  }

  async deleteNotification(id: string): Promise<boolean> {
    const result = await db.delete(notifications).where(eq(notifications.id, id)).returning();
    return result.length > 0;
  }

  // Recurring Transactions
  async getRecurringTransaction(id: string): Promise<RecurringTransaction | undefined> {
    const result = await db.select().from(recurringTransactions).where(eq(recurringTransactions.id, id)).limit(1);
    return result[0];
  }

  async getRecurringTransactionsByOrganization(organizationId: string): Promise<RecurringTransaction[]> {
    return await db
      .select()
      .from(recurringTransactions)
      .where(eq(recurringTransactions.organizationId, organizationId))
      .orderBy(desc(recurringTransactions.createdAt));
  }

  async getActiveRecurringTransactions(organizationId: string): Promise<RecurringTransaction[]> {
    return await db
      .select()
      .from(recurringTransactions)
      .where(
        and(
          eq(recurringTransactions.organizationId, organizationId),
          eq(recurringTransactions.isActive, true)
        )
      )
      .orderBy(asc(recurringTransactions.startDate));
  }

  async createRecurringTransaction(transaction: InsertRecurringTransaction): Promise<RecurringTransaction> {
    const result = await db.insert(recurringTransactions).values(transaction).returning();
    return result[0];
  }

  async updateRecurringTransaction(id: string, transaction: Partial<InsertRecurringTransaction>): Promise<RecurringTransaction | undefined> {
    const result = await db
      .update(recurringTransactions)
      .set({ ...transaction, updatedAt: new Date() })
      .where(eq(recurringTransactions.id, id))
      .returning();
    return result[0];
  }

  async deleteRecurringTransaction(id: string): Promise<boolean> {
    const result = await db.delete(recurringTransactions).where(eq(recurringTransactions.id, id)).returning();
    return result.length > 0;
  }

  // Reports
  async getDREReport(organizationId: string, startDate?: Date, endDate?: Date): Promise<any> {
    const start = startDate || new Date(new Date().getFullYear(), 0, 1);
    const end = endDate || new Date();

    // Get all transactions for the period
    const allTransactions = await db
      .select()
      .from(transactions)
      .where(
        and(
          eq(transactions.organizationId, organizationId),
          gte(transactions.date, start),
          lte(transactions.date, end)
        )
      );

    // Get categories for grouping
    const categoriesData = await db
      .select()
      .from(categories)
      .where(eq(categories.organizationId, organizationId));

    // Calculate totals
    const receitas = allTransactions
      .filter(t => t.type === 'income' && t.isPaid)
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);

    const despesas = allTransactions
      .filter(t => t.type === 'expense' && t.isPaid)
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);

    // Group by category
    const receitasPorCategoria = categoriesData
      .filter(c => c.type === 'income')
      .map(cat => ({
        categoria: cat.name,
        valor: allTransactions
          .filter(t => t.categoryId === cat.id && t.isPaid && t.type === 'income')
          .reduce((sum, t) => sum + parseFloat(t.amount), 0)
      }))
      .filter(c => c.valor > 0);

    const despesasPorCategoria = categoriesData
      .filter(c => c.type === 'expense')
      .map(cat => ({
        categoria: cat.name,
        valor: allTransactions
          .filter(t => t.categoryId === cat.id && t.isPaid && t.type === 'expense')
          .reduce((sum, t) => sum + parseFloat(t.amount), 0)
      }))
      .filter(c => c.valor > 0);

    const lucroLiquido = receitas - despesas;

    return {
      periodo: {
        inicio: start,
        fim: end
      },
      receitas: {
        total: receitas,
        porCategoria: receitasPorCategoria
      },
      despesas: {
        total: despesas,
        porCategoria: despesasPorCategoria
      },
      lucroLiquido,
      margemLucro: receitas > 0 ? (lucroLiquido / receitas) * 100 : 0
    };
  }

  async getCashFlowReport(organizationId: string, startDate?: Date, endDate?: Date): Promise<any> {
    const start = startDate || new Date(new Date().getFullYear(), 0, 1);
    const end = endDate || new Date();

    // Get all transactions for the period
    const allTransactions = await db
      .select()
      .from(transactions)
      .where(
        and(
          eq(transactions.organizationId, organizationId),
          gte(transactions.date, start),
          lte(transactions.date, end)
        )
      )
      .orderBy(asc(transactions.date));

    // Get initial balance from bank accounts
    const bankAccountsData = await db
      .select()
      .from(bankAccounts)
      .where(eq(bankAccounts.organizationId, organizationId));

    const saldoInicial = bankAccountsData.reduce(
      (sum, acc) => sum + parseFloat(acc.initialBalance || '0'),
      0
    );

    // Calculate monthly cash flow
    const monthlyData: any[] = [];
    let runningBalance = saldoInicial;

    // Group transactions by month
    const months = new Map<string, { entradas: number; saidas: number }>();

    allTransactions.forEach(t => {
      if (!t.isPaid) return;

      const monthKey = new Date(t.date).toISOString().substring(0, 7); // YYYY-MM
      if (!months.has(monthKey)) {
        months.set(monthKey, { entradas: 0, saidas: 0 });
      }
      const month = months.get(monthKey)!;

      if (t.type === 'income') {
        month.entradas += parseFloat(t.amount);
      } else {
        month.saidas += parseFloat(t.amount);
      }
    });

    // Create monthly flow data
    months.forEach((data, monthKey) => {
      const fluxoMes = data.entradas - data.saidas;
      runningBalance += fluxoMes;

      monthlyData.push({
        mes: monthKey,
        entradas: data.entradas,
        saidas: data.saidas,
        fluxoLiquido: fluxoMes,
        saldoAcumulado: runningBalance
      });
    });

    const totalEntradas = allTransactions
      .filter(t => t.type === 'income' && t.isPaid)
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);

    const totalSaidas = allTransactions
      .filter(t => t.type === 'expense' && t.isPaid)
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);

    return {
      periodo: {
        inicio: start,
        fim: end
      },
      saldoInicial,
      totalEntradas,
      totalSaidas,
      fluxoLiquidoTotal: totalEntradas - totalSaidas,
      saldoFinal: saldoInicial + totalEntradas - totalSaidas,
      fluxoMensal: monthlyData
    };
  }

  async getStatementReport(organizationId: string, startDate?: Date, endDate?: Date): Promise<any> {
    const start = startDate || new Date(new Date().setDate(new Date().getDate() - 30));
    const end = endDate || new Date();

    // Get all transactions for the period with related data
    const transactionsData = await db
      .select({
        transaction: transactions,
        category: categories,
        bankAccount: bankAccounts,
        costCenter: costCenters,
      })
      .from(transactions)
      .leftJoin(categories, eq(transactions.categoryId, categories.id))
      .leftJoin(bankAccounts, eq(transactions.bankAccountId, bankAccounts.id))
      .leftJoin(costCenters, eq(transactions.costCenterId, costCenters.id))
      .where(
        and(
          eq(transactions.organizationId, organizationId),
          gte(transactions.date, start),
          lte(transactions.date, end)
        )
      )
      .orderBy(desc(transactions.date));

    const extrato = transactionsData.map(row => ({
      id: row.transaction.id,
      data: row.transaction.date,
      descricao: row.transaction.description,
      tipo: row.transaction.type,
      valor: parseFloat(row.transaction.amount),
      categoria: row.category?.name || 'Sem categoria',
      contaBancaria: row.bankAccount?.name || 'Sem conta',
      centroCusto: row.costCenter?.name,
      pago: row.transaction.isPaid,
      dataPagamento: row.transaction.paidDate,
      observacoes: row.transaction.notes
    }));

    const totalReceitas = extrato
      .filter(e => e.tipo === 'income' && e.pago)
      .reduce((sum, e) => sum + e.valor, 0);

    const totalDespesas = extrato
      .filter(e => e.tipo === 'expense' && e.pago)
      .reduce((sum, e) => sum + e.valor, 0);

    return {
      periodo: {
        inicio: start,
        fim: end
      },
      transacoes: extrato,
      totalizadores: {
        totalReceitas,
        totalDespesas,
        saldo: totalReceitas - totalDespesas,
        totalTransacoes: extrato.length,
        receitasPagas: extrato.filter(e => e.tipo === 'income' && e.pago).length,
        despesasPagas: extrato.filter(e => e.tipo === 'expense' && e.pago).length,
        pendentes: extrato.filter(e => !e.pago).length
      }
    };
  }

  // Password Reset Methods
  async getUserById(id: string): Promise<User | undefined> {
    return this.getUser(id);
  }

  async setPasswordResetToken(userId: string, token: string, expiry: Date): Promise<void> {
    await db
      .update(users)
      .set({ resetToken: token, resetTokenExpiry: expiry, updatedAt: new Date() })
      .where(eq(users.id, userId));
  }

  async getUserByResetToken(token: string): Promise<User | undefined> {
    const result = await db
      .select()
      .from(users)
      .where(eq(users.resetToken, token))
      .limit(1);
    return result[0];
  }

  async updateUserPassword(userId: string, hashedPassword: string): Promise<void> {
    await db
      .update(users)
      .set({ password: hashedPassword, updatedAt: new Date() })
      .where(eq(users.id, userId));
  }

  async clearPasswordResetToken(userId: string): Promise<void> {
    await db
      .update(users)
      .set({ resetToken: null, resetTokenExpiry: null, updatedAt: new Date() })
      .where(eq(users.id, userId));
  }

  // Email Verification Methods
  async setEmailVerificationToken(userId: string, token: string): Promise<void> {
    await db
      .update(users)
      .set({ verificationToken: token, updatedAt: new Date() })
      .where(eq(users.id, userId));
  }

  async getUserByVerificationToken(token: string): Promise<User | undefined> {
    const result = await db
      .select()
      .from(users)
      .where(eq(users.verificationToken, token))
      .limit(1);
    return result[0];
  }

  async verifyUserEmail(userId: string): Promise<void> {
    await db
      .update(users)
      .set({ emailVerified: true, verificationToken: null, updatedAt: new Date() })
      .where(eq(users.id, userId));
  }

  async markEmailAsVerified(userId: string): Promise<void> {
    await this.verifyUserEmail(userId);
  }

  // API Keys Methods
  async createApiKey(apiKey: InsertApiKey): Promise<ApiKey> {
    const result = await db.insert(apiKeys).values(apiKey).returning();
    return result[0];
  }

  async getApiKeyByHash(keyHash: string): Promise<ApiKey | undefined> {
    const result = await db
      .select()
      .from(apiKeys)
      .where(eq(apiKeys.keyHash, keyHash))
      .limit(1);
    return result[0];
  }

  async getApiKeysByOrganization(organizationId: string): Promise<ApiKey[]> {
    return await db
      .select()
      .from(apiKeys)
      .where(eq(apiKeys.organizationId, organizationId))
      .orderBy(desc(apiKeys.createdAt));
  }

  async updateApiKeyLastUsed(id: string): Promise<void> {
    await db
      .update(apiKeys)
      .set({ lastUsedAt: new Date(), updatedAt: new Date() })
      .where(eq(apiKeys.id, id));
  }

  async updateApiKey(id: string, apiKey: Partial<InsertApiKey>): Promise<ApiKey | undefined> {
    const result = await db
      .update(apiKeys)
      .set({ ...apiKey, updatedAt: new Date() })
      .where(eq(apiKeys.id, id))
      .returning();
    return result[0];
  }

  async deleteApiKey(id: string): Promise<boolean> {
    const result = await db.delete(apiKeys).where(eq(apiKeys.id, id)).returning();
    return result.length > 0;
  }
}

export const storage = new DbStorage();
