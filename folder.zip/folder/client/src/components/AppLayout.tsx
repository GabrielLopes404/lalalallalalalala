import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  Users,
  FileText,
  Settings,
  LogOut,
  Menu,
  X,
  Sparkles,
  Moon,
  Sun,
  Receipt,
  BarChart3,
  Import,
  HelpCircle,
  ChevronDown,
  Bell,
  Check,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import HelpButton from "@/components/HelpButton";
import { differenceInDays } from "date-fns";

interface AppLayoutProps {
  children: React.ReactNode;
}

interface NavItem {
  name: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
}

const navigation: NavItem[] = [
  { name: "Página inicial", href: "/app/dashboard", icon: LayoutDashboard },
  { name: "Transações", href: "/app/transactions", icon: Receipt },
  { name: "Contatos", href: "/app/customers", icon: Users },
  { name: "Relatórios", href: "/app/reports", icon: BarChart3 },
  { name: "Importações", href: "/app/imports", icon: Import },
  { name: "Conciliações (OFX)", href: "/app/reconciliations", icon: FileText },
];

export default function AppLayout({ children }: AppLayoutProps) {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [daysLeft, setDaysLeft] = useState(7);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('darkMode');
      return saved ? JSON.parse(saved) : false;
    }
    return false;
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await fetch("/api/auth/me", {
          credentials: "include",
        });

        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
          
          // Calculate days left in trial
          const userCreatedAt = new Date(data.user.createdAt || Date.now());
          const trialEndDate = new Date(userCreatedAt);
          trialEndDate.setDate(trialEndDate.getDate() + 7);
          const days = differenceInDays(trialEndDate, new Date());
          setDaysLeft(Math.max(0, days));
        } else {
          setLocation("/login");
        }
      } catch (error) {
        console.error("Failed to fetch user:", error);
        setLocation("/login");
      }
    };

    fetchUser();
  }, [setLocation]);

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const response = await fetch("/api/notifications?limit=5", {
          credentials: "include",
        });

        if (response.ok) {
          const data = await response.json();
          setNotifications(data.notifications || []);
          setUnreadCount(data.unreadCount || 0);
        }
      } catch (error) {
        console.error("Failed to fetch notifications:", error);
      }
    };

    if (user) {
      fetchNotifications();
      const interval = setInterval(fetchNotifications, 30000);
      return () => clearInterval(interval);
    }
  }, [user]);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('darkMode', JSON.stringify(darkMode));
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const handleMarkAsRead = async (notificationId: number) => {
    try {
      const csrfResponse = await fetch('/api/csrf-token', { credentials: 'include' });
      const { csrfToken } = await csrfResponse.json();

      await fetch(`/api/notifications/${notificationId}/read`, {
        method: "PUT",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
      });

      setNotifications(prev => prev.map(n => 
        n.id === notificationId ? { ...n, read: true } : n
      ));
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (error) {
      console.error("Failed to mark notification as read:", error);
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      const csrfResponse = await fetch('/api/csrf-token', { credentials: 'include' });
      const { csrfToken } = await csrfResponse.json();

      await fetch("/api/notifications/mark-all-read", {
        method: "PUT",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
      });

      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      setUnreadCount(0);
    } catch (error) {
      console.error("Failed to mark all as read:", error);
    }
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include",
      });

      toast({
        title: "Logout realizado",
        description: "Até logo!",
      });

      setLocation("/");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao fazer logout",
        description: "Tente novamente.",
      });
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="lg:grid lg:grid-cols-[280px_1fr]">
        <aside
          className={`fixed inset-y-0 left-0 z-50 w-72 bg-card border-r transform transition-transform duration-200 ease-in-out lg:relative lg:translate-x-0 ${
            sidebarOpen ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <div className="flex h-16 items-center justify-between px-6 border-b">
            <div className="flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                LUCREI
              </span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          <nav className="flex-1 space-y-1 px-4 py-4 overflow-y-auto">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.href;

              return (
                <Button
                  key={item.name}
                  variant={isActive ? "secondary" : "ghost"}
                  className="w-full justify-start gap-3 h-10"
                  onClick={() => {
                    setLocation(item.href);
                    setSidebarOpen(false);
                  }}
                >
                  <Icon className="h-4 w-4 flex-shrink-0" />
                  <span className="text-sm">{item.name}</span>
                </Button>
              );
            })}
          </nav>

          <div className="border-t">
            <div className="p-4 space-y-2">
              <Button
                variant="ghost"
                className="w-full justify-start gap-3 h-10"
                onClick={() => {
                  setLocation("/app/settings");
                  setSidebarOpen(false);
                }}
              >
                <Settings className="h-4 w-4" />
                <span className="text-sm">Configurações</span>
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="w-full justify-start gap-3 h-10">
                    <HelpCircle className="h-4 w-4" />
                    <span className="text-sm flex-1 text-left">Ajuda</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem>Videoaulas para iniciantes</DropdownMenuItem>
                  <DropdownMenuItem>Guias de ajuda</DropdownMenuItem>
                  <DropdownMenuItem>Dicas</DropdownMenuItem>
                  <DropdownMenuItem>Dê seu feedback</DropdownMenuItem>
                  <DropdownMenuItem>Outros canais de ajuda</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <div className="border-t p-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="w-full justify-start gap-3 h-auto py-2 px-2">
                    <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-semibold text-primary">
                        {user.name?.charAt(0).toUpperCase() || user.username?.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0 text-left">
                      <p className="text-sm font-medium truncate">{user.name || user.username}</p>
                      <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                    </div>
                    <ChevronDown className="h-4 w-4 flex-shrink-0" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem onClick={() => setLocation("/app/profile")}>
                    Meu perfil de usuário
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/settings")}>
                    Configurações de {user.name || user.username}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/accounts")}>
                    Minhas contas
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/categories")}>
                    Categorias
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/cost-centers")}>
                    Centros de Custo
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/bank-accounts")}>
                    Contas Bancárias
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/documents")}>
                    Documentos
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/tags")}>
                    Tags / Marcadores
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/export")}>
                    Exportar dados
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setLocation("/app/subscription")}>
                    Gerenciar minha assinatura
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/pricing")}>
                    Assinar plano...
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </aside>

        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        <div className="flex flex-col min-h-screen">
          <div className="relative overflow-hidden bg-gradient-to-r from-violet-600/90 via-purple-600/90 to-violet-600/90 backdrop-blur-sm border-b border-violet-400/20 shadow-lg">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.1),transparent)]" />
            <div className="relative flex flex-col sm:flex-row items-center justify-between gap-1 sm:gap-2 px-3 sm:px-4 py-1.5 sm:py-2 text-white max-w-7xl mx-auto">
              <div className="flex items-center gap-1.5 sm:gap-2 text-[10px] sm:text-xs md:text-sm">
                <div className="hidden md:flex h-6 w-6 sm:h-8 sm:w-8 rounded-full bg-white/20 items-center justify-center">
                  <Sparkles className="h-3 w-3 sm:h-4 sm:w-4 text-white" />
                </div>
                <span className="text-white/90 font-medium">
                  Período de avaliação:{" "}
                  <span className="font-bold text-white">
                    {daysLeft} {daysLeft === 1 ? 'dia' : 'dias'} restante{daysLeft !== 1 ? 's' : ''}
                  </span>
                </span>
              </div>
              <div className="flex items-center gap-1.5 sm:gap-2">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setLocation("/app/pricing")}
                  className="text-white hover:bg-white/20 h-6 sm:h-7 px-2 sm:px-3 text-[10px] sm:text-xs font-semibold transition-all duration-200 border border-white/30 hover:border-white/50 rounded-md sm:rounded-lg backdrop-blur-sm"
                >
                  Ver Planos
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setLocation("/app/subscription")}
                  className="text-white bg-white/15 hover:bg-white/25 h-6 sm:h-7 px-2 sm:px-3 text-[10px] sm:text-xs font-semibold transition-all duration-200 rounded-md sm:rounded-lg backdrop-blur-sm"
                >
                  Assinar Agora
                </Button>
              </div>
            </div>
          </div>
          <header className="sticky top-0 z-30 h-16 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            <div className="flex h-full items-center gap-2 px-4 sm:px-6">
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </Button>
              <div className="flex-1" />
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative">
                    <Bell className="h-5 w-5" />
                    {unreadCount > 0 && (
                      <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center font-semibold">
                        {unreadCount > 9 ? '9+' : unreadCount}
                      </span>
                    )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-96">
                  <div className="flex items-center justify-between p-3 border-b">
                    <h3 className="font-semibold">Notificações</h3>
                    {unreadCount > 0 && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={handleMarkAllAsRead}
                        className="h-7 text-xs"
                      >
                        <Check className="h-3 w-3 mr-1" />
                        Marcar todas como lidas
                      </Button>
                    )}
                  </div>
                  <div className="max-h-[400px] overflow-y-auto">
                    {notifications.length === 0 ? (
                      <div className="p-6 text-center text-sm text-muted-foreground">
                        Você não possui novas notificações
                      </div>
                    ) : (
                      notifications.map((notification: any) => (
                        <div
                          key={notification.id}
                          className={`p-3 border-b last:border-b-0 cursor-pointer hover:bg-accent transition-colors ${
                            !notification.read ? 'bg-blue-50 dark:bg-blue-950/20' : ''
                          }`}
                          onClick={() => handleMarkAsRead(notification.id)}
                        >
                          <div className="flex items-start gap-3">
                            <div className="flex-1">
                              <p className="font-medium text-sm">{notification.title}</p>
                              <p className="text-xs text-muted-foreground mt-1">
                                {notification.message}
                              </p>
                              <p className="text-xs text-muted-foreground mt-2">
                                {new Date(notification.createdAt).toLocaleString('pt-BR')}
                              </p>
                            </div>
                            {!notification.read && (
                              <div className="h-2 w-2 rounded-full bg-blue-500 flex-shrink-0 mt-1" />
                            )}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>

              <Button
                variant="ghost"
                size="icon"
                onClick={toggleDarkMode}
                title={darkMode ? "Modo claro" : "Modo escuro"}
              >
                {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
            </div>
          </header>

          <main className="flex-1 p-4 sm:p-6 lg:p-8">
            {children}
          </main>
        </div>
      </div>
      
      <HelpButton />
    </div>
  );
}
