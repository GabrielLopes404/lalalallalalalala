import { Card } from "@/components/ui/card";
import { 
  TrendingUp, 
  Users, 
  FileText, 
  BarChart3, 
  Shield, 
  Zap,
  Sparkles,
  ArrowRight
} from "lucide-react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";

const benefits = [
  {
    icon: TrendingUp,
    title: "Gestão Financeira Completa",
    description: "Controle total de receitas, despesas e fluxo de caixa em tempo real. Visualize suas métricas financeiras de forma clara e objetiva.",
    gradient: "from-blue-500 via-cyan-500 to-blue-600",
    glowColor: "rgba(6, 182, 212, 0.3)"
  },
  {
    icon: Users,
    title: "Gestão de Clientes",
    description: "Organize seus clientes, histórico de transações e documentos em um só lugar. Relacionamento profissional e eficiente.",
    gradient: "from-purple-500 via-fuchsia-500 to-pink-500",
    glowColor: "rgba(217, 70, 239, 0.3)"
  },
  {
    icon: FileText,
    title: "Faturas Inteligentes",
    description: "Crie, envie e acompanhe faturas profissionais. Controle de vencimentos e pagamentos automático.",
    gradient: "from-green-500 via-emerald-500 to-teal-500",
    glowColor: "rgba(16, 185, 129, 0.3)"
  },
  {
    icon: BarChart3,
    title: "Relatórios e Analytics",
    description: "Dashboards personalizados com métricas importantes: MRR, ARR, taxa de conversão e muito mais.",
    gradient: "from-orange-500 via-amber-500 to-yellow-500",
    glowColor: "rgba(251, 146, 60, 0.3)"
  },
  {
    icon: Shield,
    title: "Segurança Empresarial",
    description: "Seus dados protegidos com criptografia de nível bancário. Backups automáticos e recuperação de desastres.",
    gradient: "from-indigo-500 via-violet-500 to-purple-600",
    glowColor: "rgba(139, 92, 246, 0.3)"
  },
  {
    icon: Zap,
    title: "Automação Inteligente",
    description: "Automatize cobranças, lembretes de pagamento e reconciliação bancária. Foque no que importa.",
    gradient: "from-rose-500 via-pink-500 to-fuchsia-500",
    glowColor: "rgba(244, 63, 94, 0.3)"
  }
];

export default function BenefitsSection() {
  const ref = useRef(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["100px", "-100px"]);

  return (
    <section ref={containerRef} id="beneficios" className="relative py-32 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Ultra vibrant background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-violet-500/5 via-fuchsia-500/5 to-background" />
      
      {/* Animated gradient orbs */}
      <motion.div
        style={{ y }}
        className="absolute top-20 left-10 w-96 h-96 bg-gradient-to-r from-violet-500/20 to-fuchsia-500/20 rounded-full blur-3xl"
      />
      <motion.div
        style={{ y: useTransform(scrollYProgress, [0, 1], ["-50px", "150px"]) }}
        className="absolute bottom-20 right-10 w-96 h-96 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-full blur-3xl"
      />

      {/* Grid pattern overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(139,92,246,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(139,92,246,0.03)_1px,transparent_1px)] bg-[size:64px_64px]" />
      
      <div ref={ref} className="max-w-[1440px] mx-auto relative z-10">
        {/* Enhanced header */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-center mb-20"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2, duration: 0.6, type: "spring" }}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-violet-500/10 via-fuchsia-500/10 to-cyan-500/10 border border-violet-500/20 backdrop-blur-xl shadow-lg mb-8 relative overflow-hidden"
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
              animate={{ x: ['-200%', '200%'] }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear", repeatDelay: 1 }}
            />
            <Sparkles className="h-5 w-5 text-violet-500" />
            <span className="text-sm font-bold bg-gradient-to-r from-violet-600 via-fuchsia-600 to-cyan-600 bg-clip-text text-transparent">
              Recursos Premium Inclusos
            </span>
          </motion.div>
          
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight" data-testid="text-benefits-title">
            <span className="bg-gradient-to-r from-foreground to-foreground/90 bg-clip-text text-transparent">
              Tudo que você precisa
            </span>
            <br />
            <span className="relative inline-block">
              <motion.span
                className="absolute -inset-2 bg-gradient-to-r from-violet-500 via-fuchsia-500 to-cyan-500 blur-2xl opacity-30"
                animate={{ opacity: [0.3, 0.5, 0.3] }}
                transition={{ duration: 3, repeat: Infinity }}
              />
              <span className="relative bg-gradient-to-r from-violet-600 via-fuchsia-600 to-cyan-600 bg-clip-text text-transparent">
                para crescer sem limites
              </span>
            </span>
          </h2>
          <p className="text-xl sm:text-2xl text-muted-foreground max-w-3xl mx-auto font-light" data-testid="text-benefits-subtitle">
            Ferramentas profissionais com{" "}
            <span className="font-semibold text-foreground">inteligência artificial integrada</span>
            {" "}para transformar sua gestão financeira
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 60, rotateX: -10 }}
              animate={isInView ? { opacity: 1, y: 0, rotateX: 0 } : {}}
              transition={{ 
                delay: 0.1 * index, 
                duration: 0.8,
                type: "spring",
                stiffness: 100
              }}
              whileHover={{ y: -12, scale: 1.02 }}
              style={{ transformStyle: 'preserve-3d', perspective: '1000px' }}
            >
              <Card 
                className="relative p-8 group h-full overflow-hidden border border-violet-500/10 backdrop-blur-xl bg-gradient-to-br from-background/80 via-background/50 to-background/80 hover:border-violet-500/30 transition-all duration-500 shadow-xl hover:shadow-2xl"
                data-testid={`card-benefit-${index}`}
              >
                {/* Animated gradient background on hover */}
                <motion.div
                  className={`absolute -inset-px bg-gradient-to-br ${benefit.gradient} rounded-lg opacity-0 group-hover:opacity-20 blur-xl transition-all duration-700`}
                  style={{ filter: 'blur(20px)' }}
                />

                {/* Shimmer effect */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100"
                  animate={{
                    x: ['-200%', '200%'],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    repeatDelay: 3,
                    ease: "linear"
                  }}
                />
                
                {/* Gradient border on hover */}
                <div className={`absolute -inset-0.5 bg-gradient-to-br ${benefit.gradient} rounded-lg opacity-0 group-hover:opacity-100 blur transition-opacity duration-500 -z-10`} />

                <div className="relative z-10 space-y-6">
                  {/* Enhanced icon with 3D effect */}
                  <motion.div
                    whileHover={{ scale: 1.15, rotateY: 180 }}
                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                    className="relative"
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <div className={`h-16 w-16 rounded-2xl bg-gradient-to-br ${benefit.gradient} p-0.5 shadow-2xl group-hover:shadow-lg transition-all duration-500`}
                      style={{ boxShadow: `0 10px 40px ${benefit.glowColor}` }}
                    >
                      <div className="h-full w-full rounded-2xl bg-background/90 backdrop-blur-xl flex items-center justify-center group-hover:bg-transparent transition-all duration-500">
                        <benefit.icon className="h-8 w-8 text-foreground group-hover:text-white transition-colors duration-500" />
                      </div>
                    </div>
                    
                    {/* Floating particles around icon */}
                    <motion.div
                      className={`absolute -top-1 -right-1 w-2 h-2 rounded-full bg-gradient-to-r ${benefit.gradient}`}
                      animate={{
                        y: [-3, 3, -3],
                        opacity: [0.5, 1, 0.5],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                    />
                  </motion.div>

                  <div>
                    <h3 className={`text-2xl font-bold mb-3 group-hover:bg-gradient-to-r ${benefit.gradient} group-hover:bg-clip-text group-hover:text-transparent transition-all duration-300`} data-testid={`text-benefit-title-${index}`}>
                      {benefit.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed text-base group-hover:text-foreground/80 transition-colors duration-300" data-testid={`text-benefit-description-${index}`}>
                      {benefit.description}
                    </p>
                  </div>

                  {/* Learn more link */}
                  <motion.div
                    initial={{ opacity: 0, x: -10 }}
                    whileHover={{ x: 5 }}
                    className="flex items-center gap-2 text-sm font-semibold opacity-0 group-hover:opacity-100 transition-all duration-300"
                  >
                    <span className={`bg-gradient-to-r ${benefit.gradient} bg-clip-text text-transparent`}>
                      Saiba mais
                    </span>
                    <ArrowRight className={`h-4 w-4 bg-gradient-to-r ${benefit.gradient} bg-clip-text text-transparent`} />
                  </motion.div>
                </div>

                {/* Bottom gradient line */}
                <motion.div
                  className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${benefit.gradient}`}
                  initial={{ scaleX: 0 }}
                  whileHover={{ scaleX: 1 }}
                  transition={{ duration: 0.4 }}
                />
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA section */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="text-center mt-20"
        >
          <p className="text-lg text-muted-foreground mb-6">
            E muito mais recursos sendo adicionados toda semana
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            {['Conciliação bancária', 'Importação OFX', 'Multi-moeda', 'API completa'].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ delay: 1 + i * 0.1 }}
                whileHover={{ scale: 1.1 }}
                className="px-4 py-2 rounded-full bg-gradient-to-r from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20 backdrop-blur-sm text-sm font-medium"
              >
                ✨ {feature}
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
