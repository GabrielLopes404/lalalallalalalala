import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  TrendingUp, 
  Shield, 
  BarChart3, 
  Zap, 
  Globe, 
  Users,
  ArrowLeft,
  FileText,
  Clock,
  DollarSign,
  Bell,
  Lock,
  Smartphone
} from "lucide-react";
import { motion } from "framer-motion";

export default function RecursosPage() {
  const [, setLocation] = useLocation();

  const features = [
    {
      icon: TrendingUp,
      title: "Análise em Tempo Real",
      description: "Monitore seu fluxo de caixa e métricas financeiras em tempo real com dashboards intuitivos e atualizações instantâneas."
    },
    {
      icon: Shield,
      title: "Segurança Empresarial",
      description: "Criptografia de ponta a ponta, conformidade com LGPD e backups automáticos para proteção total dos seus dados."
    },
    {
      icon: BarChart3,
      title: "Relatórios Avançados",
      description: "Gere relatórios personalizados com filtros avançados e visualizações de dados para insights poderosos."
    },
    {
      icon: Zap,
      title: "Automação Inteligente",
      description: "Automatize processos repetitivos como importação de extratos, categorização e reconciliação bancária."
    },
    {
      icon: Globe,
      title: "Acesso em Qualquer Lugar",
      description: "Plataforma em nuvem 100% web, acessível de qualquer dispositivo com internet."
    },
    {
      icon: Users,
      title: "Gestão de Equipes",
      description: "Controle de permissões granular, colaboração em tempo real e auditoria completa de ações."
    },
    {
      icon: FileText,
      title: "Gestão de Documentos",
      description: "Armazene e organize documentos fiscais, contratos e comprovantes em um só lugar."
    },
    {
      icon: Clock,
      title: "Histórico Completo",
      description: "Mantenha registros detalhados de todas as transações e atividades da sua empresa."
    },
    {
      icon: DollarSign,
      title: "Conciliação Bancária",
      description: "Importe extratos OFX e reconcilie automaticamente com suas transações."
    },
    {
      icon: Bell,
      title: "Notificações Inteligentes",
      description: "Receba alertas sobre vencimentos, metas e eventos importantes via email."
    },
    {
      icon: Lock,
      title: "Controle de Acesso",
      description: "Sistema RBAC com permissões personalizáveis por usuário e função."
    },
    {
      icon: Smartphone,
      title: "Design Responsivo",
      description: "Interface adaptável para desktop, tablet e smartphone com a mesma experiência."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")} 
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
            Recursos Poderosos
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Tudo que você precisa para transformar sua gestão financeira
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center flex-shrink-0">
                      <feature.icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                      <p className="text-muted-foreground">{feature.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="text-center mt-16"
        >
          <Button 
            size="lg"
            onClick={() => setLocation("/register")}
            className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
          >
            Começar Agora Gratuitamente
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
